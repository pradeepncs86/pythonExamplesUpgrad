from dataclasses import dataclass
from datetime import datetime
from typing import List

@dataclass
class MigrationStatus:
    app_id: str
    app_name: str
    migration_stage: str
    completion_percentage: float
    blockers: List[str]
    last_updated: datetime
    assigned_team: str
    jira_tickets: List[str]
