class AppDataTool:
    pass
