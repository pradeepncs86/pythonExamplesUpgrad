class HardGateTool:
    pass
