class JiraTool:
    pass
