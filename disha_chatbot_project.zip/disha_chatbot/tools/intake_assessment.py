class IntakeAssessmentTool:
    pass
