class FAISSEmbeddingStore:
    pass
